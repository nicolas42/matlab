from neural_network.init import Init
from neural_network.activation import Activation


class NN(Init, Activation):
    pass